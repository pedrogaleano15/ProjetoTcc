import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../dashboard/dashboard_screen.dart';
import '../relatorios/historico_movimentacoes_screen.dart';
import '../dashboard/menu_manejo.dart';

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Painel do Gestor'),
        backgroundColor: AppTheme.secondary,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSaudacao(),
              const SizedBox(height: 24),
              const Text(
                'Módulos de Gestão',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textSecondary,
                  letterSpacing: 0.8,
                ),
              ),
              const SizedBox(height: 12),
              Expanded(child: _buildGrid(context)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSaudacao() {
    final hora = DateTime.now().hour;
    final saudacao = hora < 12
        ? 'Bom dia'
        : hora < 18
        ? 'Boa tarde'
        : 'Boa noite';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '$saudacao, Gestor 👋',
          style: const TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w800,
            color: AppTheme.textPrimary,
          ),
        ),
        const SizedBox(height: 4),
        const Text(
          'Nome da fazenda, localização ou slogan',
          style: TextStyle(fontSize: 14, color: AppTheme.textSecondary),
        ),
      ],
    );
  }

  Widget _buildGrid(BuildContext context) {
    final modulos = [
      _ModuloInfo(
        titulo: 'Visão Geral (BI)',
        subtitulo: 'Gráficos e indicadores',
        icone: Icons.pie_chart_rounded,
        cor: AppTheme.primary,
        tela: const DashboardScreen(),
      ),
      _ModuloInfo(
        titulo: 'Auditoria',
        subtitulo: 'Histórico de eventos',
        icone: Icons.history_rounded,
        cor: const Color(0xFF1565C0),
        tela: const HistoricoMovimentacoesScreen(),
      ),
      _ModuloInfo(
        titulo: 'Gestão do Rebanho',
        subtitulo: 'Lista completa de animais',
        icone: Icons.pets_rounded,
        cor: AppTheme.secondary,
        tela: const MenuManejoScreen(),
      ),
      // Reservado para módulos futuros
      _ModuloInfo(
        titulo: 'Relatório IA',
        subtitulo: 'Análise com Gemini',
        icone: Icons.psychology_rounded,
        cor: const Color(0xFF6A1B9A),
        tela: null, // Em breve
      ),
    ];

    return GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 14,
        mainAxisSpacing: 14,
        childAspectRatio: 1.0,
      ),
      itemCount: modulos.length,
      itemBuilder: (context, index) => _AdminCard(modulo: modulos[index]),
    );
  }
}

// ─── Modelo de dados do módulo ───────────────────────────────────────────────

class _ModuloInfo {
  const _ModuloInfo({
    required this.titulo,
    required this.subtitulo,
    required this.icone,
    required this.cor,
    required this.tela,
  });

  final String titulo;
  final String subtitulo;
  final IconData icone;
  final Color cor;
  final Widget? tela; // null = em breve
}

// ─── Card do módulo ──────────────────────────────────────────────────────────

class _AdminCard extends StatelessWidget {
  const _AdminCard({required this.modulo});

  final _ModuloInfo modulo;

  @override
  Widget build(BuildContext context) {
    final emBreve = modulo.tela == null;

    return Opacity(
      opacity: emBreve ? 0.55 : 1.0,
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        elevation: 2,
        shadowColor: Colors.black12,
        child: InkWell(
          onTap: emBreve
              ? () => _mostrarEmBreve(context)
              : () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => modulo.tela!),
                ),
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: modulo.cor.withOpacity(0.25),
                width: 1.5,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: modulo.cor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(modulo.icone, color: modulo.cor, size: 26),
                ),
                const Spacer(),
                Text(
                  modulo.titulo,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                    color: AppTheme.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  emBreve ? 'Em breve' : modulo.subtitulo,
                  style: TextStyle(
                    fontSize: 11,
                    color: emBreve ? AppTheme.warning : AppTheme.textSecondary,
                    fontWeight: emBreve ? FontWeight.w600 : FontWeight.normal,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _mostrarEmBreve(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${modulo.titulo} estará disponível em breve.'),
        backgroundColor: AppTheme.secondary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}
